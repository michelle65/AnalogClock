import './App.css';
import Clock from './Components/Clock/Clock.jsx';
function App() {
  return (
  <div className="container">
    <Clock/>
  </div>
  );
}

export default App;
